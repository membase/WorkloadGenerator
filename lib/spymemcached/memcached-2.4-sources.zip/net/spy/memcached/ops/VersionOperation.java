package net.spy.memcached.ops;

/**
 * Version operation.
 */
public interface VersionOperation extends Operation {
	// nothing
}