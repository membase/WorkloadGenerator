package net.spy.memcached.ops;

/**
 * The NOOP Operation.
 */
public interface NoopOperation extends Operation {
	// Nothing
}
