package net.spy.memcached.ops;


/**
 * Deletion operation.
 */
public interface DeleteOperation extends KeyedOperation {
	// nothing in particular.
}