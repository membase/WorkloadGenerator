package net.spy.memcached.ops;


/**
 * Flush operation marker.
 */
public interface FlushOperation extends Operation {
	// nothing
}